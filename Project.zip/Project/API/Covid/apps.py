from django.apps import AppConfig


class ClickbaitConfig(AppConfig):
    name = 'Clickbaits'
