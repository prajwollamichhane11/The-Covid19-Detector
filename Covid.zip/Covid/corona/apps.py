from django.apps import AppConfig


class CoronaConfig(AppConfig):
    name = 'corona'
